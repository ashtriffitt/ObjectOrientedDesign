import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

import controller.Controller;
import controller.ControllerImpl;
import controller.commands.Load;
import model.Store;
import model.StoreImage;
import view.ImageView;
import view.View;
import controller.commands.Script;

/**
 * The class that will carry out the functionality of the image processing program.
 */
public class ImageProcessing {

  /**
   * The main method that will initialize the program and allow the user to interact with it
   * using a series of image processing commands.
   *
   * @param args the command line arguments
   * @throws IOException loaded file must exist
   */
  public static void main(String[] args) throws IOException {
    Readable inputReader = new InputStreamReader(System.in);
    Scanner s = new Scanner(inputReader);
    Store imageStore = new StoreImage();
    View view = new ImageView(imageStore);

    System.out.println("Load initial image: ");
    String fileName = s.next();
    System.out.println("Enter storage name: ");
    String imageName = s.next();

    Load load = new Load(fileName, imageName);
    load.loadType(imageStore);

    System.out.println("Enter Command: ");

    Readable in = new InputStreamReader(System.in);
    Controller controller = new ControllerImpl(imageStore, view, in, imageName);

    controller.runProgram();
    /*
    Readable inputReader = new InputStreamReader(System.in);
    Scanner s = new Scanner(inputReader);
    Store imageStore = new StoreImage();
    View view = new ImageView(imageStore);

    System.out.println("Type Script to load script\nPress any key to run manually");
    if (s.next().equals("Script")) {
      System.out.println("Load script: ");
      String scriptFile = s.next();
      int typeStart = scriptFile.lastIndexOf(".");
      String type = scriptFile.substring(typeStart + 1);
      if (type.equals("txt")) {
        //System.out.println("its in here");
        File file = new File(scriptFile);
        InputStream in = new FileInputStream(file);
        Controller controller = new ControllerImpl(imageStore, view, new InputStreamReader(in),
                "whatever");
        controller.runProgram();

        //Script script = new Script(scriptFile);
      }
      else {
        System.out.println("not a script text file.");
      }
    }
    else {
      System.out.println("Load initial image: ");
      String fileName = s.next();
      System.out.println("Enter storage name: ");
      String imageName = s.next();

      Load load = new Load(fileName, imageName);
      load.loadType(imageStore);

      System.out.println("Enter Command: ");

      Readable in = new InputStreamReader(System.in);
      Controller controller = new ControllerImpl(imageStore, view, in, "sample");
      controller.runProgram();
    }

     */
  }
}
