package view;

import java.io.IOException;

import model.Image;
import model.Pixel;
import model.Store;

/**
 * Represents the implementation of the view and how it will be displayed to the user.
 */
public class ImageView implements View {
  private Store imageStore;
  private Appendable destination;

  /**
   * Creates a new view instance with a default appendable of System.out.
   *
   * @param imageStore the collection of stored images
   * @throws IllegalArgumentException the provided collection must contain images.
   */
  public ImageView(Store imageStore) throws IllegalArgumentException {
    if (imageStore == null) {
      throw new IllegalArgumentException("provided model is null");
    }
    this.imageStore = imageStore;
    this.destination = System.out;
  }

  /**
   * Creates a new view instance with a customizable appendable.
   *
   * @param imageStore the collection of stored images
   * @throws IllegalArgumentException the provided collection must contain images.
   */
  public ImageView(Store imageStore, Appendable destination) throws IllegalArgumentException {
    if (this.imageStore == null || this.destination == null) {
      throw new IllegalArgumentException("provided model is null");
    }
    this.imageStore = imageStore;
    this.destination = destination;
  }

  @Override
  public String toString(String filename) throws IllegalStateException {
    Image image;
    StringBuilder display;

    try {
      image = imageStore.contain(filename);
    } catch (Exception e) {
      throw new IllegalStateException("image is not stored");
    }
    Pixel[][] imageCopy = image.getPixels();

    display = new StringBuilder("Height of Image: " + image.getHeight() + '\n'
            + "Width of Image: " + image.getWidth() + '\n'
            + "Maximum value of a color in this file (usually 255): " + image.getMaxVal() + '\n');

    for (int i = 0; i < imageCopy.length; i++) {
      StringBuilder rgb = new StringBuilder(" ");
      for (int j = 0; j < imageCopy[i].length; j++) {
        rgb.append("(");
        for (int x = 0; x < 3; x++) {
          rgb.append(imageCopy[i][j].getColor().get(x));
          if (x == 0 || x == 1) {
            rgb.append(", ");
          }
        }
        rgb.append(")");
      }
      display.append(rgb);
    }
    System.out.println(display);
    System.out.println("Enter Command: ");
    return display.toString();
  }

  @Override
  public void renderMessage(String message) throws IOException {
    try {
      this.destination.append(message + '\n');
    } catch (Exception e) {
      throw new IllegalStateException("message is null");
    }
  }
}
