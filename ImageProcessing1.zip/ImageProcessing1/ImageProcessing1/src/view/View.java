package view;

import java.io.IOException;

/**
 * Represents the interface that will be displayed to the user.
 */
public interface View {

  /**
   * Outputs the PPM file as a string, allowing the user to see the information about the image.
   *
   * @param filename the filename to be printed out
   * @return the file in string format
   * @throws IllegalStateException the file must exist
   */
  String toString(String filename) throws IllegalStateException;

  /**
   * Renders messages to the user while using the program.
   *
   * @param message the message to be rendered
   * @throws IOException message must be non-null
   */
  void renderMessage(String message) throws IOException;
}
