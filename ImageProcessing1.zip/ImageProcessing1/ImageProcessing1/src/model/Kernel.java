package model;

/**
 * Interface that represents a kernel of an image.
 */
public interface Kernel {

  /**
   * Gets a kernel of an image.
   *
   * @param image the image to get a kernel from
   * @param x     the x coordinate of the pixel
   * @param y     the y coordinate of the pixel
   * @return a new array that consists of the kernel pixels
   * @throws IllegalArgumentException the pixel must be located in the bounds of the image
   */
  PixelImpl[][] kernelGetter(PixelImpl[][] image, int x, int y)
          throws IllegalArgumentException;

}
