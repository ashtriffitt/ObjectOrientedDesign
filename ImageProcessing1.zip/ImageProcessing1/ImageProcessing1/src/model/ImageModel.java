package model;

/**
 * Represents the implementation of all the functionality of an image.
 */
public class ImageModel implements Image {
  private int width;
  private int height;
  private int maxValue;
  private PixelImpl[][] image;

  /**
   * Creates a new instance of an image.
   *
   * @param width the image width
   * @param height the image height
   * @param maxValue the max color value of the image
   * @param image the pixels of the image
   */
  public ImageModel(int width, int height, int maxValue, PixelImpl[][] image)
          throws IllegalArgumentException {
    if (width < 1 || height < 1 || maxValue < 1 || image == null) {
      throw new IllegalArgumentException("Image model must exist");
    }
    this.width = width;
    this.height = height;
    this.maxValue = maxValue;
    this.image = image;
  }

  @Override
  public int getWidth() {
    return this.width;
  }

  @Override
  public int getHeight() {
    return this.height;
  }

  @Override
  public int getMaxVal() {
    return this.maxValue;
  }

  @Override
  public PixelImpl[][] getPixels() {
    PixelImpl[][] imageCopy = this.image;
    return imageCopy;
  }

  @Override
  public PixelImpl[][] flipVertical() {
    PixelImpl[][] imageCopy = this.image;
    int c = imageCopy[0].length / 2;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        if (c > j) {
          PixelImpl pixel = imageCopy[i][j];
          imageCopy[i][j] = imageCopy[i][getHeight() - 1 - j];
          imageCopy[i][getHeight() - 1 - j] = pixel;
        }
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] flipHorizontal() {
    PixelImpl[][] imageCopy = this.image;
    int c = imageCopy.length / 2;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        if (c > i) {
          PixelImpl pixel = imageCopy[i][j];
          imageCopy[i][j] = imageCopy[getWidth() - 1 - i][j];
          imageCopy[getWidth() - 1 - i][j] = pixel;


        }

      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] visualizeColor(int color) throws IllegalArgumentException {
    PixelImpl[][] imageCopy = this.getPixels();
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].visualizeColor(color);
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] visValue() {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].visValue();
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] visIntensity() {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].visIntensity();
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] visLuma() {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].visLuma();
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] brighten(int value) throws IllegalArgumentException {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].brighten(value);
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] darken(int value) throws IllegalArgumentException {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].darken(value);
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] blur() {
    PixelImpl[][] imageCopy = this.image;
    KernelImpl newKernel = new KernelImpl(3);
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].blur(newKernel.kernelGetter(imageCopy, i, j));
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] sharpen() {
    PixelImpl[][] imageCopy = this.image;
    KernelImpl newKernel = new KernelImpl(5);
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {

        imageCopy[i][j].sharpen(newKernel.kernelGetter(imageCopy, i, j));
      }
    }
    return imageCopy;
  }

  @Override
  public PixelImpl[][] sepia() {
    PixelImpl[][] imageCopy = this.image;
    for (int i = 0; i < this.getWidth(); i++) {
      for (int j = 0; j < this.getHeight(); j++) {
        imageCopy[i][j].sepia();
      }
    }
    return imageCopy;
  }
}
