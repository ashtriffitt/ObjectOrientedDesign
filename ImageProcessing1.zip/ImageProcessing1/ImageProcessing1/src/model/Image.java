package model;

/**
 * Represents an image and all of its supported commands.
 */
public interface Image {

  /**
   * Gets the width of the image.
   *
   * @return image width
   */
  int getWidth();

  /**
   * Gets the height of the image.
   *
   * @return image height
   */
  int getHeight();

  /**
   * Gets the max color value of the image.
   *
   * @return image max color value
   */
  int getMaxVal();

  /**
   * Gets the pixels of the image.
   *
   * @return all image pixels
   */
  PixelImpl[][] getPixels();

  /**
   * Flips the image vertically.
   *
   * @return the vertically flipped pixels
   */
  PixelImpl[][] flipVertical();

  /**
   * Flips the image horizontally.
   *
   * @return the horizontally flipped pixels
   */
  PixelImpl[][] flipHorizontal();

  /**
   * Visualizes the image using red, green, or blue value.
   *
   * @param color the color to be visualized (0 = red, 1 = blue, 2 = green)
   * @return the visualized pixels
   * @throws IllegalArgumentException color must be between 0 - 2
   */
  PixelImpl[][] visualizeColor(int color) throws IllegalArgumentException;

  /**
   * Visualizes the image using its value.
   *
   * @return the visualized pixels
   */
  PixelImpl[][] visValue();

  /**
   * Visualizes the image using its intensity.
   *
   * @return the visualized pixels
   */
  PixelImpl[][] visIntensity();

  /**
   * Visualizes the image using its luma.
   *
   * @return the visualized pixels
   */
  PixelImpl[][] visLuma();

  /**
   * Brightens the image by a specific value.
   *
   * @param value the amount the image is to be brightened by
   * @return the brightened pixels
   * @throws IllegalArgumentException the brightening value must be a positive integer
   */
  PixelImpl[][] brighten(int value) throws IllegalArgumentException;

  /**
   * Darkens the image by a specific value.
   *
   * @param value the amount the image is to be darkened by
   * @return the darkened pixels
   * @throws IllegalArgumentException the darkening value must be a positive integer
   */
  PixelImpl[][] darken(int value) throws IllegalArgumentException;

  /**
   * Blurs a image.
   * @return The blurred image.
   */
  PixelImpl[][] blur();

  /**
   * Sharpens an image.
   * @return the sharpened image.
   */
  PixelImpl[][] sharpen();

  /**
   * Applies sepia filter to an image.
   * @return the filtered image.
   */
  PixelImpl[][] sepia();

}
