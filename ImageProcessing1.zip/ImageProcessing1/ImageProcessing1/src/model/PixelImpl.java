package model;

import java.util.List;

/**
 * The implementation of the functionality of each pixel of an image.
 */
public class PixelImpl implements Pixel {
  private List<Integer> rgbVal;

  /**
   * Creates a new pixel instance.
   *
   * @param rgbVal the rgb value of the pixel
   */
  public PixelImpl(List<Integer> rgbVal) throws IllegalArgumentException {
    if (rgbVal == null) {
      throw new IllegalArgumentException("RGB value cannot be null");
    }
    this.rgbVal = rgbVal;
  }

  @Override
  public List<Integer> getColor() {
    return this.rgbVal;
  }

  @Override
  public List<Integer> visualizeColor(int color) throws IllegalArgumentException {
    if (color > 3 || color < 0) {
      throw new IllegalArgumentException("Color must be 0-2");
    }
    int rgbValue = this.rgbVal.get(color);
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, rgbValue);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> visValue() {
    int value;
    if (rgbVal.get(0) > rgbVal.get(1) && rgbVal.get(0) > rgbVal.get(2)) {
      value = rgbVal.get(0);
    } else if (rgbVal.get(1) > rgbVal.get(2)) {
      value = rgbVal.get(1);
    } else {
      value = rgbVal.get(2);
    }
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, value);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> visIntensity() {
    int intensity;
    intensity = ((rgbVal.get(0) + rgbVal.get(1) + rgbVal.get(2)) / 3);
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, intensity);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> visLuma() {
    int luma;
    luma = (int) Math.round((0.2126 * rgbVal.get(0)) + (0.7152 * rgbVal.get(1))
            + (0.0722 * rgbVal.get(2)));
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, luma);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> brighten(int value) throws IllegalArgumentException {
    if (value < 0) {
      throw new IllegalArgumentException("brighten value must be greater than 0");
    }
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, rgbVal.get(i) + value);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> darken(int value) throws IllegalArgumentException {
    if (value < 0) {
      throw new IllegalArgumentException("darken value must be greater than 0");
    }
    for (int i = 0; i < 3; i++) {
      this.rgbVal.set(i, rgbVal.get(i) - value);
    }
    return rgbVal;
  }

  @Override
  public List<Integer> blur(PixelImpl[][] kernel) throws IllegalArgumentException {
    if (kernel.length != 3) {
      throw new IllegalArgumentException("Kernel size must be 3");
    }
    int newRed = 0;
    int newBlue = 0;
    int newGreen = 0;
    double[][] blurArray = {
            {.0625, .125, .0625},
            {.125, .25, .125},
            {.0625, .125, .0625}
    };

    for (int i = 0; i < kernel.length; i++) {
      for (int j = 0; j < kernel[0].length; j++) {
        if (kernel[i][j] == null) {}
        else {
          newRed += kernel[i][j].rgbVal.get(0) * blurArray[i][j];
          newGreen += kernel[i][j].rgbVal.get(1) * blurArray[i][j];
          newBlue += kernel[i][j].rgbVal.get(2) * blurArray[i][j];
        }
      }
    }
    rgbVal.set(0, newRed);
    rgbVal.set(1, newGreen);
    rgbVal.set(2, newBlue);

    return rgbVal;
  }

  @Override
  public List<Integer> sharpen(PixelImpl[][] kernel) throws IllegalArgumentException {
    if (kernel.length != 5) {
      throw new IllegalArgumentException("Kernel size must be 5");
    }
    int newRed = 0;
    int newBlue = 0;
    int newGreen = 0;
    double[][] sharpenArray = {
            {-.125, -.125, -.125, -.125 , -.125},
            {-.125, .25, .25, .25, -.125},
            {-.125, .25, 1, .25, -.125},
            {-.125, .25, .25, .25, -.125},
            {-.125, -.125, -.125, -.125 , -.125}
    };

    for (int i = 0; i < kernel.length; i++) {
      for (int j = 0; j < kernel[0].length; j++) {
        if (kernel[i][j] == null) {}
        else {
          newRed += kernel[i][j].rgbVal.get(0) * sharpenArray[i][j];
          newGreen += kernel[i][j].rgbVal.get(1) * sharpenArray[i][j];
          newBlue += kernel[i][j].rgbVal.get(2) * sharpenArray[i][j];
        }
      }
    }
    rgbVal.set(0, newRed);
    rgbVal.set(1, newGreen);
    rgbVal.set(2, newBlue);

    return rgbVal;
  }

  @Override
  public List<Integer> sepia() {
    int newRed = 0;
    int newBlue = 0;
    int newGreen = 0;

    newRed = (int) (0.393 * rgbVal.get(0) + 0.769 * rgbVal.get(1) + 0.189 * rgbVal.get(2));
    newGreen = (int) (0.349 * rgbVal.get(0) + 0.686 * rgbVal.get(1) + 0.168 * rgbVal.get(2));
    newBlue = (int) (0.272 * rgbVal.get(0) + 0.534 * rgbVal.get(1) + 0.131 * rgbVal.get(2));

    rgbVal.set(0, newRed);
    rgbVal.set(1, newGreen);
    rgbVal.set(2, newBlue);

    return rgbVal;
  }
}

