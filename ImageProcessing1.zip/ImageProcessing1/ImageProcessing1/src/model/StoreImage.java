package model;

import java.util.HashMap;
import java.util.Map;

/**
 * The implementation of storing an image.
 */
public class StoreImage implements Store {

  private Map<String, Image> storedImage;

  /**
   * Creates a new image storage collection represented by a hashmap.
   */
  public StoreImage() {
    this.storedImage = new HashMap<>();
  }

  @Override
  public void put(String key, Image image) throws IllegalArgumentException {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    this.storedImage.put(key, image);
  }

  @Override
  public Image contain(String filename) {
    Image imageCopy;
    imageCopy = this.storedImage.getOrDefault(filename, null);
    return imageCopy;
  }
}
