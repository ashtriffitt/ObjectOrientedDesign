package model;

import java.util.List;

/**
 * Represents the changes that can be made to a pixel and the information about each pixel.
 */
public interface Pixel {

  /**
   * Gets the color of the pixel.
   *
   * @return pixel color
   */
  List<Integer> getColor();

  /**
   * Visualizes a pixel to the selected RGB value.
   *
   * @param color the color to be visualized (red = 0 , blue = 1, green = 2)
   * @return the visualized pixel
   * @throws IllegalArgumentException selected color must be 0 - 2
   */
  List<Integer> visualizeColor(int color) throws IllegalArgumentException;

  /**
   * Visualizes a pixel to its value.
   *
   * @return the visualized pixel
   */
  List<Integer> visValue();

  /**
   * Visualizes a pixel to its intensity.
   *
   * @return the visualized pixel
   */
  List<Integer> visIntensity();

  /**
   * Visualizes a pixel to its luma.
   *
   * @return the visualized pixel
   */
  List<Integer> visLuma();

  /**
   * Brightens a pixel to the selected value.
   *
   * @param value the amount the pixel is to be brightened
   * @return the brightened pixel
   * @throws IllegalArgumentException the brightening value must be a positive integer
   */
  List<Integer> brighten(int value) throws IllegalArgumentException;

  /**
   * Darkens a pixel to the selected value.
   *
   * @param value the amount the pixel is to be darkened
   * @return the darkened pixel
   * @throws IllegalArgumentException the darkening value must be a positive integer
   */
  List<Integer> darken(int value) throws IllegalArgumentException;

  /**
   * Blurs a pixel.
   *
   * @param kernel The kernel of the pixel to be blurred
   * @return The blurred pixel
   * @throws IllegalArgumentException if kernel size isn't 3
   */
  List<Integer> blur(PixelImpl[][] kernel) throws IllegalArgumentException;

  /**
   * Sharpens a pixel.
   *
   * @param kernel The kernel of the pixel to be sharpened
   * @return The sharpened pixel
   * @throws IllegalArgumentException if kernel size isn't 5
   */
  List<Integer> sharpen(PixelImpl[][] kernel) throws IllegalArgumentException;

  /**
   * Applies sepia filter to a pixel.
   *
   * @return The sepia filtered pixel.
   */
  List<Integer> sepia();

}
