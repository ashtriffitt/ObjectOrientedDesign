package model;

/**
 * Implementation of the kernel interface that will get the kernel for each pixel of an image.
 */
public class KernelImpl implements Kernel {

  private int size;

  /**
   * Creates a new instance of a kernel with a given size.
   *
   * @param size size of the kernel array
   * @throws IllegalArgumentException the kernel size must be odd
   */
  public KernelImpl(int size) throws IllegalArgumentException {
    if (size % 2 == 0) {
      throw new IllegalArgumentException("Size must be odd.");
    }
    this.size = size;
  }

  @Override
  public PixelImpl[][] kernelGetter(PixelImpl[][] image, int x, int y) throws IllegalArgumentException {
    if (x < 0 || x > image.length || y < 0 || y > image[0].length) {
      throw new IllegalArgumentException("X or Y have to be on the image.");
    }
    PixelImpl[][] kernel = new PixelImpl[size][size];

    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        if ((x - (size / 2) + i) >= image.length || (x - (size / 2) + i) < 0 ||
                (y - (size / 2) + j) >= image[0].length || (y - (size / 2) + j) < 0) {
          kernel[i][j] = null;
        }
        else {
          kernel[i][j] = image[x - (size / 2) + i][y - (size / 2) + j];
        }
      }
    }
    return kernel;
  }
}
