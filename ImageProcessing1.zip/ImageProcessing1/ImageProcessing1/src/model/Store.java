package model;

/**
 * The collection of images that are stored and can be edited.
 */
public interface Store {

  /**
   * Puts the image into a hashmap with a specific key to be called by, so it can be edited.
   *
   * @param key the name the image will be referred to
   * @param image the image being added
   * @throws IllegalArgumentException the image must not be null (ie. exist)
   */
  void put(String key, Image image) throws IllegalArgumentException;

  /**
   * Gets the image from the hashmap based on its selected name.
   *
   * @param filename the name of the image
   * @return the image attached to the inputted name
   */
  Image contain(String filename);
}