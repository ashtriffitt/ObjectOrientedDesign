package controller.commands;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

import controller.ImageProcessingCommand;
import model.ImageModel;
import model.PixelImpl;
import model.Store;

/**
 * Represents the class that will load the given PPM file into the program.
 */
public class LoadPPM implements Loader {
  private String filename;

  /**
   * Creates a new load instance.
   *
   * @param filename the name of the file to be loaded
   * @throws IllegalArgumentException the file must not be null
   */
  public LoadPPM(String filename) throws IllegalArgumentException {
    if (filename == null) {
      throw new IllegalArgumentException("Cannot load file");
    }
    this.filename = filename;
  }

  @Override
  public ImageModel load() throws IllegalStateException {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(filename));
    } catch (FileNotFoundException e) {
      throw new IllegalStateException("File " + filename + " not found!");
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();

    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();
    PixelImpl[][] image = new PixelImpl[height][width];

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        image[i][j] = new PixelImpl(Arrays.asList(r, g, b));
      }
    }
    return new ImageModel(height, width, maxValue, image);
  }
}
