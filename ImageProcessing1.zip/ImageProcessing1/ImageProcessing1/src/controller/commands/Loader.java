package controller.commands;

import model.ImageModel;

/**
 * Represents the ability to load various file formats (ie. JPG, BMP, PNG, PPM)
 */
public interface Loader {

  /**
   * Loads in an image to the image processing program.
   *
   * @return the loaded image
   * @throws IllegalStateException the image must exist
   */
  ImageModel load() throws IllegalStateException;
}
