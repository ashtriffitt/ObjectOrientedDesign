package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command to visualize the intensity of an image.
 */
public class VisualizeIntensity implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new instance of visualize intensity.
   *
   * @param input the file to be visualized
   * @param output the new name of the edited file
   */
  public VisualizeIntensity(String input, String output) {
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) {
    visualizeInt(imageStore);
  }

  /**
   * Visualizes the intensity of an image.
   *
   * @param imageStore the collection of stored images that can be modified
   */
  public void visualizeInt(Store imageStore) {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.visIntensity();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
