package controller.commands;

import java.beans.BeanInfo;
import java.io.IOException;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;
import view.ImageView;
import view.View;

/**
 * Represents the command to visualize the image as a specific RGB color.
 */
public class VisualizeColor implements ImageProcessingCommand {
  private String input;
  private String output;
  private String colorVis;

  /**
   * Creates a new visualize by an RGB instance.
   *
   * @param input the current file name of the image to be edited
   * @param output the new name of the edited image
   * @param colorVis the visualized RGB color
   */
  public VisualizeColor(String input, String output, String colorVis)
          throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("The input and output must be non-null");
    }
    this.input = input;
    this.output = output;
    this.colorVis = colorVis;
  }

  @Override
  public void runCommand(Store imageStore) throws IOException {
    visualizeRGB(imageStore);
  }

  /**
   * Visualizes the image by the selected RGB value.
   *
   * @param imageStore the collection of stored images that can be modified
   */
  public void visualizeRGB(Store imageStore) throws IOException {
    Image image = imageStore.contain(this.input);
    int colorNum = 0;
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    if (colorVis.equals("red")) {
      colorNum = 0;
    } else if (colorVis.equals("green")) {
      colorNum = 1;
    } else if (colorVis.equals("blue")) {
      colorNum = 2;
    }
    image.visualizeColor(colorNum);
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
