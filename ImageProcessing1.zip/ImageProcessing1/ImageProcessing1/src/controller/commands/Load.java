package controller.commands;

import java.io.IOException;

import controller.ImageProcessingCommand;
import model.ImageModel;
import model.Store;

/**
 * Represents the ability to load in a new file (of various types) to the image processing program.
 */
public class Load implements ImageProcessingCommand {
  private String filename;
  private String output;

  /**
   * Creates a new load instance.
   *
   * @param filename the name of the file to be loaded
   * @param output the name that the loaded file will be called
   */
  public Load(String filename, String output) {
    this.filename = filename;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) throws IOException {
    System.out.println(imageStore);
    loadType(imageStore);
  }

  /**
   * Determines what type of file is being loaded and runs the appropriate load class.
   *
   * @param imageStore the collection of images stored
   */
  public void loadType(Store imageStore) {
    int typeStart = this.filename.lastIndexOf(".");
    String type = filename.substring(typeStart + 1);
    Loader toLoad;
    if(type.equals("ppm")) {
      toLoad = new LoadPPM(filename);
    }
    else {
      toLoad = new LoadFile(filename);
    }
    ImageModel image;

    try {
      image = toLoad.load();
      imageStore.put(output, image);
      System.out.println(filename);
      System.out.println("Loaded: " + filename + '\n'
              + "Named: " + output);
    } catch (IllegalStateException e) {
      throw new IllegalStateException("File could not be loaded");
    }
  }
}
