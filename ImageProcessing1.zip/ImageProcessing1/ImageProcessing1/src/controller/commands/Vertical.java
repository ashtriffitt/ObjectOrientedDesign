package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command to flip and image vertically.
 */
public class Vertical implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new vertical flip instance.
   *
   * @param input the current name of the file
   * @param output the new name of the flipped image
   */
  public Vertical(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("The input and output must be non-null");
    }
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) {
    flipVertical(imageStore);
  }

  /**
   * Command to flip the image vertically.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image must be loaded
   */
  public void flipVertical(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.flipVertical();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
