package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command that will flip an image horizontally.
 */
public class Horizontal implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new instance of the horizontal flip command.
   *
   * @param input  the name of the image to be flipped
   * @param output the name that the flipped image will be referred to
   */
  public Horizontal(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("Input and output must be non-null");
    }
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) {
    flipHorizontal(imageStore);
  }

  /**
   * Flips the given stored image horizontally and outputs that the modification occurred.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image to be flipped must be stored
   */
  public void flipHorizontal(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.flipHorizontal();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
