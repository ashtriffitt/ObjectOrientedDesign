package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command that will darken the image.
 */
public class Darken implements ImageProcessingCommand {
  private String input;
  private String output;
  private int amount;

  /**
   * Creates a new darkening instance.
   *
   * @param input the name of the file to darken
   * @param output the new name of the darkened file
   * @param amount the positive integer amount to darken the image by
   * @throws IllegalArgumentException input and output must be non-null and the darken amount must
   *                                  be greater than 0.
   */
  public Darken(String input, String output, int amount) {
    if (input == null || output == null || amount < 1) {
      throw new IllegalArgumentException("Input and output cannot be null and darken amount must "
              + "be greater than 0");
    }
    this.input = input;
    this.output = output;
    this.amount = amount;
  }

  @Override
  public void runCommand(Store imageStore) {
    darkenImage(imageStore);
  }

  /**
   * Darkens the given stored image and outputs that the modification occurred.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image to be darkened must be stored
   */
  public void darkenImage(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.darken(amount);
    imageStore.put(this.output, image);
    System.out.println(amount);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
