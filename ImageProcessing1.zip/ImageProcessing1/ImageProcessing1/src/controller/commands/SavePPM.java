package controller.commands;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;

import controller.ImageProcessingCommand;
import model.Store;

/**
 * Represents the command to save a modified image as a PPM.
 */
public class SavePPM implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new save instance.
   *
   * @param input the file to be saved
   * @param output the name the file will be saved as
   */
  public SavePPM(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("The input and output must be non-null");
    }
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) throws IOException {
    saveImage(imageStore, output, input);
  }

  /**
   * Saves a modified image as its new given name as a PPM.
   *
   * @param imageStore the collection of stored images that can be saved
   * @param filename the current file name
   * @param output the new name of the saved file
   * @throws IOException the file must be written successfully
   */
  public void saveImage(Store imageStore, String filename, String output) throws IOException {

    BufferedWriter writer = null;
    try {
      File file = new File(filename + "ppm");
      StringBuilder content = new StringBuilder();

      if (!file.exists()) {
        file.createNewFile();
      }

      FileWriter fw = new FileWriter(file);

      writer = new BufferedWriter(fw);

      int height = imageStore.contain(output).getHeight();
      int width = imageStore.contain(output).getWidth();
      content.append("P3");
      content.append("\n");
      content.append(width + " " + height);
      content.append("\n");
      content.append(imageStore.contain(output).getMaxVal() + "");
      content.append("\n");
      for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
          content.append(imageStore.contain(output).getPixels()[i][j].getColor().get(0) + " ");
          content.append(imageStore.contain(output).getPixels()[i][j].getColor().get(1) + " ");
          content.append(imageStore.contain(output).getPixels()[i][j].getColor().get(2) + " ");
        }
        content.append("\n");
      }
      writer.write(String.valueOf(content));
      System.out.println("File written successfully");

    } catch (IOException e) {
      e.printStackTrace();
    }
    finally {
      try {
        if (writer != null) {
          writer.close();
        }
      } catch (Exception exception) {
        System.out.println("Error in closing the BufferedWriter" + exception);
      }
    }
  }
}
