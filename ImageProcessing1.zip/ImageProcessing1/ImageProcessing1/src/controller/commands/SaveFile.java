package controller.commands;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.imageio.ImageIO;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command to save a general file type (JPG, PNG, BMP).
 */
public class SaveFile implements ImageProcessingCommand {
  private String input;
  private String output;
  private String format;

  /**
   * Creates a new save instance.
   *
   * @param input the file to be saved
   * @param output the name the file will be saved as
   * @param format the type of file to be saved
   */
  public SaveFile(String input, String output, String format) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("The input and output must be non-null");
    }
    this.input = input;
    this.output = output;
    this.format = format;
  }

  @Override
  public void runCommand(Store imageStore) throws IOException {
    save(imageStore, output, input, format);
  }

  /**
   * Saves an image in a general form (JPG, PNG, PPM) to the disk.
   *
   * @param imageStore the collection of loaded images
   * @param filename the name of the file to be saved
   * @param output the name of the saved file
   * @param format the desired format (PNG, JPG, BMP)
   * @throws IllegalArgumentException the image to save must exist
   */
  public void save(Store imageStore, String filename, String output, String format)
          throws IllegalArgumentException {
    BufferedImage imageCopy = null;
    Image image;

    try {
      image = imageStore.contain(output);
    } catch (IllegalStateException e) {
      throw new IllegalArgumentException("image does not exist");
    }

    if (format.equals("PNG")) {
      imageCopy = new BufferedImage(image.getWidth(), image.getHeight(),
              BufferedImage.TYPE_4BYTE_ABGR);

      for (int i = 0; i < image.getWidth(); i++) {
        for (int j = 0; j < image.getHeight(); j++) {
          List<Integer> rgb = image.getPixels()[i][j].getColor();
          Color color;
          if (rgb.size() < 4) {
            color = new Color(rgb.get(0), rgb.get(1), rgb.get(2));
          }
          else {
            color = new Color(rgb.get(0), rgb.get(1), rgb.get(2), rgb.get(3));
          }
          imageCopy.setRGB(i, j, color.getRGB());
        }
      }
    }
    else {
      imageCopy = new BufferedImage(image.getWidth(), image.getHeight(),
              BufferedImage.TYPE_INT_RGB);

      for (int i = 0; i < image.getWidth(); i++) {
        for (int j = 0; j < image.getHeight(); j++) {
          List<Integer> rgb = image.getPixels()[i][j].getColor();
          Color color = new Color(rgb.get(0), rgb.get(1), rgb.get(2));

          imageCopy.setRGB(i, j, color.getRGB());
        }
      }
    }
    try {
      ImageIO.write(imageCopy, format.toLowerCase(),
              new File(filename + "." + format.toLowerCase()));
    } catch (IOException e) {
      throw new IllegalStateException("Could not save file");
    }
  }
}
