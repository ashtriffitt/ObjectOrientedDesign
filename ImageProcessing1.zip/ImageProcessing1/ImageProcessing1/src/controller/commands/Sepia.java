package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command to apply a sepia color transformation to an image.
 */
public class Sepia implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new instance of a sepia color transformation.
   *
   * @param input the name of the file to be edited
   * @param output the name of the edited file
   * @throws IllegalArgumentException input and output cannot be null
   */
  public Sepia(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("Input and output cannot be null");
    }
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) {
    sepiaFilterImage(imageStore);
  }

  /**
   * Sepia filters the given stored image and outputs that the modification occurred.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image to be filtered must be stored
   */
  public void sepiaFilterImage(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.sepia();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
