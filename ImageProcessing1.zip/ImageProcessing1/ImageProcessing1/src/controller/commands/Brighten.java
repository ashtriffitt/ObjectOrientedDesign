package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command that will brighten the image.
 */
public class Brighten implements ImageProcessingCommand {
  private String input;
  private String output;
  private int amount;

  /**
   * Creates a new brightening instance.
   *
   * @param input  the name of the file to brighten
   * @param output the new name of the brightened file
   * @param amount the positive integer amount to brighten the image by
   * @throws IllegalArgumentException input and output must be non-null and the brighten amount must
   *                                  be greater than 0.
   */
  public Brighten(String input, String output, int amount) throws IllegalArgumentException {
    if (input == null || output == null || amount < 1) {
      throw new IllegalArgumentException("Input and output cannot be null and brighten amount must "
              + "be greater than 0");
    }
    this.input = input;
    this.output = output;
    this.amount = amount;
  }

  @Override
  public void runCommand(Store imageStore) {
    brightenImage(imageStore);
  }

  /**
   * Brightens the given stored image and outputs that the modification occurred.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image to be brightened must be stored
   */
  public void brightenImage(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.brighten(amount);
    imageStore.put(this.output, image);
    System.out.println(amount);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}

