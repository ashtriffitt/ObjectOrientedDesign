package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the class that will blur an image.
 */
public class Blur implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new instance of the blue command.
   *
   * @param input the current file name to be blurred
   * @param output the name of the blurred file.
   * @throws IllegalArgumentException input and output cannot be null
   */
  public Blur(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("Input and output cannot be null");
    }
    this.input = input;
    this.output = output;
  }

  /**
   * Runs the blurImage command. Helper method to be called in the controller.
   *
   * @param imageStore the collection of stored images
   */
  @Override
  public void runCommand(Store imageStore) {
    blurImage(imageStore);
  }

  /**
   * Blurs the given stored image and outputs that the modification occurred.
   *
   * @param imageStore the collection of stored images that can be modified
   * @throws IllegalArgumentException the image to be blurred must be stored
   */
  public void blurImage(Store imageStore) throws IllegalArgumentException {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.blur();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
