package controller.commands;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

import model.ImageModel;
import model.PixelImpl;

/**
 * Represents the command to load in general file type (JPG, BMP, PNG).
 */
public class LoadFile implements Loader{
  private String filename;

  /**
   * Creates a new load instance for a general file type.
   *
   * @param filename the name of the file to be loaded
   * @throws IllegalArgumentException the file must not be null
   */
  public LoadFile(String filename) throws IllegalArgumentException {
    if (filename == null) {
      throw new IllegalArgumentException("Cannot load file");
    }
    this.filename = filename;
  }

  @Override
  public ImageModel load() throws IllegalStateException {
    File file = new File(this.filename);
    BufferedImage loadImage = null;

    try {
      loadImage = ImageIO.read(file);

    } catch (IOException e) {
      throw new IllegalStateException("image does not exist");
    }

    int height = loadImage.getHeight();
    int width = loadImage.getWidth();
    PixelImpl[][] pixels = new PixelImpl[height][width];

    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int pixel = loadImage.getRGB(i, j);
        Color color = new Color(pixel, true);
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        pixels[i][j] = new PixelImpl(Arrays.asList(r, g , b));
      }
    }
    return new ImageModel(width, height, 255, pixels);
  }
}
