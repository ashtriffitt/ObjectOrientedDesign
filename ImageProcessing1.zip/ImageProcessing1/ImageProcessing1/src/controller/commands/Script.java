package controller.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import controller.Controller;
import controller.ControllerImpl;
import model.Store;
import model.StoreImage;
import view.ImageView;
import view.View;

public class Script {

  File script;
  String filename;

  public Script (String filename) throws IOException {
    this.filename = filename;
    script = new File(filename);
    execute();
  }

  private void execute() throws IOException {
    BufferedReader br = new BufferedReader(new FileReader(filename));
    String everything = "";
    try {
      StringBuilder sb = new StringBuilder();
      String line = br.readLine();

      while (line != null) {
        sb.append(line);
        sb.append("\n");
        line = br.readLine();
      }
      everything = sb.toString();
      System.out.println(everything);
    } finally {
      br.close();
    }


    Readable readable = new StringReader(everything);
    Store imageStore = new StoreImage();
    View imageView = new ImageView(imageStore);
    Controller controller = new ControllerImpl(imageStore, imageView, readable, "poop");
    controller.runProgram();

    /* String[] commands = everything.split("\n");
    for (int i = 0; i < commands.length; i++) {
      Controller controller = new ControllerImpl()
    }
    */

  }
}
