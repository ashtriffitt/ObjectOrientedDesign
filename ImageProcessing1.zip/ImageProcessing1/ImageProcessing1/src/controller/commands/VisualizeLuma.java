package controller.commands;

import controller.ImageProcessingCommand;
import model.Image;
import model.Store;

/**
 * Represents the command to visualize the luma of an image.
 */
public class VisualizeLuma implements ImageProcessingCommand {
  private String input;
  private String output;

  /**
   * Creates a new instance of visualize luma.
   *
   * @param input the name of the file to be visualized
   * @param output the new name of the edited file
   */
  public VisualizeLuma(String input, String output) throws IllegalArgumentException {
    if (input == null || output == null) {
      throw new IllegalArgumentException("The input and output must be non-null");
    }
    this.input = input;
    this.output = output;
  }

  @Override
  public void runCommand(Store imageStore) {
    visualizeLuma(imageStore);
  }

  /**
   * Visualizes the luma of an image.
   *
   * @param imageStore the collection of stored images that can be modified
   */
  public void visualizeLuma(Store imageStore) {
    Image image = imageStore.contain(this.input);
    if (image == null) {
      throw new IllegalArgumentException("Image is not loaded");
    }
    image.visLuma();
    imageStore.put(this.output, image);
    System.out.println("Original Image: " + this.input + '\n'
            + "Modified Image: " + this.output);
  }
}
