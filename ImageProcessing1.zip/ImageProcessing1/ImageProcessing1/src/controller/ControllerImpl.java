package controller;

import java.io.IOException;
import java.util.Scanner;

import controller.commands.Blur;
import controller.commands.Brighten;
import controller.commands.Darken;
import controller.commands.Horizontal;
import controller.commands.Load;
import controller.commands.LoadPPM;
import controller.commands.LoadFile;
import controller.commands.SavePPM;
import controller.commands.SaveFile;
import controller.commands.Sepia;
import controller.commands.Sharpen;
import controller.commands.Vertical;
import controller.commands.VisualizeColor;
import controller.commands.VisualizeIntensity;
import controller.commands.VisualizeLuma;
import controller.commands.VisualizeValue;
import model.Store;
import view.View;

/**
 * Represents the implementation of the controller that will allow the user to interact with the
 * image processing program using a series of supported command to edit a given image.
 */
public class ControllerImpl implements Controller {

  private Store imageStore;
  private View imageView;
  private Readable inputReader;
  private String fileName;


  /**
   * Creates a new instance of the controller.
   *
   * @param imageStore the collection of stored images
   * @param imageView the view to be displayed to the user
   * @param inputReader the type of input that will be taken
   * @param fileName the current name of the file
   * @throws IllegalArgumentException the controller arguments cannot be null
   */
  public ControllerImpl(Store imageStore, View imageView, Readable inputReader, String fileName)
          throws IllegalArgumentException {
    if (imageStore == null || imageView == null || inputReader == null || fileName == null) {
      throw new IllegalArgumentException("Controller arguments cannot be null");
    }
    this.imageStore = imageStore;
    this.imageView = imageView;
    this.inputReader = inputReader;
    this.fileName = fileName;
  }

  @Override
  public void runProgram() throws IllegalStateException, IOException {
    Scanner scan = new Scanner(this.inputReader);
    ImageProcessingCommand cmd = null;

    while (scan.hasNext()) {
      String read = scan.next();
      System.out.println(read);
      if (read.equalsIgnoreCase("Q") || read.equalsIgnoreCase("Quit")) {
        this.imageView.renderMessage("Quit");
        return;
      }
      switch (read) {
        case "Visualize-red" :
          cmd = new VisualizeColor(scan.next(), scan.next(), "red");
          this.imageView.renderMessage("Visualized red");
          break;
        case "Visualize-green" :
          cmd = new VisualizeColor(scan.next(), scan.next(), "green");
          this.imageView.renderMessage("Visualized green");
          break;
        case "Visualize-blue" :
          cmd = new VisualizeColor(scan.next(), scan.next(), "blue");
          this.imageView.renderMessage("Visualized blue");
          break;
        case "Visualize-value" :
          cmd = new VisualizeValue(scan.next(), scan.next());
          this.imageView.renderMessage("Visualized value");
          break;
        case "Visualize-intensity" :
          cmd = new VisualizeIntensity(scan.next(), scan.next());
          this.imageView.renderMessage("Visualized intensity");
          break;
        case "Visualize-luma" :
          cmd = new VisualizeLuma(scan.next(), scan.next());
          this.imageView.renderMessage("Visualized luma");
          break;
        case "Load" :
          cmd = new Load(scan.next(), scan.next());
          this.imageView.renderMessage("Loaded Image");
          break;
        case "SavePPM" :
          cmd = new SavePPM(scan.next(), scan.next());
          this.imageView.renderMessage("Saved PPM Image");
          break;
        case "Flip-horizontal" :
          cmd = new Horizontal(scan.next(), scan.next());
          this.imageView.renderMessage("Flipped Horizontally");
          break;
        case "Flip-vertical" :
          cmd = new Vertical(scan.next(), scan.next());
          this.imageView.renderMessage("Flipped Vertically");
          break;
        case "Brighten" :
          cmd = new Brighten(scan.next(), scan.next(), scan.nextInt());
          this.imageView.renderMessage("Brightened Image by:");
          break;
        case "Darken" :
          cmd = new Darken(scan.next(), scan.next(), scan.nextInt());
          this.imageView.renderMessage("Darkened Image by:");
          break;
        case "Blur" :
          cmd = new Blur(scan.next(), scan.next());
          this.imageView.renderMessage("Blurred Image");
          break;
        case "Sharpen" :
          cmd = new Sharpen(scan.next(), scan.next());
          this.imageView.renderMessage("Sharpened Image");
          break;
        case "Sepia" :
          cmd = new Sepia(scan.next(), scan.next());
          this.imageView.renderMessage("Sepia Filtered Image");
          break;
        case "SaveFile" :
          cmd = new SaveFile(scan.next(), scan.next(), scan.next());
          this.imageView.renderMessage("Saved Image");
          break;
        default:
          cmd = null;
          break;
      }
      if (cmd != null) {
        cmd.runCommand(imageStore);
        //imageView.toString(fileName);
      }
    }
  }
}
