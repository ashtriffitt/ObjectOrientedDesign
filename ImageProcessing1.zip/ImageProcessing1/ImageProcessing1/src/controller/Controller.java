package controller;

import java.io.IOException;

/**
 * Represents the controller of the image processing program.
 * It will carry out the main go method of the program allowing it to run.
 */
public interface Controller {

  /**
   * The method of the controller that allows the image processing program to take in a series of
   * supported commands from the user and run the appropriate command to edit the given image.
   *
   * @throws IOException input must exist
   */
  void runProgram() throws IOException;
}
