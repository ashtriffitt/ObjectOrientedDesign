package controller;

import java.io.IOException;

import model.Store;

/**
 * Represents the various commands that can be accepted by the controller.
 */
public interface ImageProcessingCommand {

  /**
   * Method that will run the given command.
   *
   * @param imageStore the collection of stored images
   * @throws IOException image store must exist
   */
  void runCommand(Store imageStore) throws IOException;
}
