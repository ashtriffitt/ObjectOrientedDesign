import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;

import controller.Controller;
import controller.ControllerImpl;
import controller.commands.Load;
import controller.commands.VisualizeColor;
import model.Image;
import model.ImageModel;
import model.PixelImpl;
import model.Store;
import model.StoreImage;
import view.ImageView;
import view.View;

import static org.junit.Assert.assertEquals;

/**
 * Represents the test class for the controller.
 */
public class ControllerTest {
  Image mockImage;
  PixelImpl[][] pixels;

  private StringBuilder viewLog;
  private MockImageView mockView;

  @Before
  public void init() {
    /*
    pixels = new PixelImpl[2][2];
    pixels[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    pixels[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    pixels[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    pixels[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    mockImage = new ImageModel(2,2,255, pixels);
     */

    viewLog = new StringBuilder();
    mockView = new MockImageView(viewLog);

  }

  @Test
  public void testCommandVisColor() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Visualize-red sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Visualized red\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandVisInt() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Visualize-intensity sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Visualized intensity\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandVisLuma() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Visualize-luma sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Visualized luma\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandVisVal() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Visualize-value sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Visualized value\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandBrighten() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Brighten sample sample2 2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Brightened Image by:\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandDarken() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Darken sample sample2 2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Darkened Image by:\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandFlipVert() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Flip-vertical sample sample2 2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Flipped Vertically\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandFlipHor() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Flip-horizontal sample sample2 2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Flipped Horizontally\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandBlurPPM() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Blur sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Blurred Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandBlurGen() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("frogPNG.png", "frog");
    load.loadType(imageStore);

    Readable input = new StringReader("Blur frog frog2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frog");
    controller.runProgram();
    assertEquals("message: Blurred Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSepiaPPM() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Sepia sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Sepia Filtered Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSepiaGen() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("frogPNG.png", "frog");
    load.loadType(imageStore);

    Readable input = new StringReader("Sepia frog frog2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frog");
    controller.runProgram();
    assertEquals("message: Sepia Filtered Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSharpenPPM() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Sharpen sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Sharpened Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSharpenGen() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("frogJPEG.jpg", "frog");
    load.loadType(imageStore);

    Readable input = new StringReader("Sharpen frog frog2 2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frog");
    controller.runProgram();
    assertEquals("message: Sharpened Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandLoadPPM() throws IOException {
    Store imageStore = new StoreImage();

    Readable input = new StringReader("Load sample.ppm sample q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Loaded Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandLoadPNG() throws IOException {
    Store imageStore = new StoreImage();

    Readable input = new StringReader("Load frogPNG.png frogPNG q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frogPNG");
    controller.runProgram();
    assertEquals("message: Loaded Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSavePPM() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("Save sample sample2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Saved PPM Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSaveJPG() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("frogJPEG.jpg", "frog");
    load.loadType(imageStore);

    Readable input = new StringReader("SaveFile frog frog2 JPG q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frog");
    controller.runProgram();
    assertEquals("message: Saved Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSaveAsJPG() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("sample.ppm", "sample");
    load.loadType(imageStore);

    Readable input = new StringReader("SaveFile sample sample2 JPG q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "sample");
    controller.runProgram();
    assertEquals("message: Saved Image\nmessage: Quit", viewLog.toString());
  }

  @Test
  public void testCommandSaveAsPPM() throws IOException {
    Store imageStore = new StoreImage();
    Load load = new Load("frogPNG.png", "frog");
    load.loadType(imageStore);

    Readable input = new StringReader("Save frog frog2 q");

    Controller controller = new ControllerImpl(imageStore, mockView, input, "frog");
    controller.runProgram();
    assertEquals("message: Saved PPM Image\nmessage: Quit", viewLog.toString());
  }

  /**
   * Represents the mock view to allow for controller testing.
   * Will keep a log of what command was run.
   */
  private class MockImageView implements View {
    private StringBuilder builder;

    public MockImageView(StringBuilder builder) {
      this.builder = builder;
    }

    @Override
    public String toString(String filename) throws IllegalStateException {
      return null;
    }

    @Override
    public void renderMessage(String message) throws IOException {
      if (message.equals("Quit")) {
        builder.append("message: " + message);
      }
      else if (message != "Quit") {
        builder.append("message: " + message + "\n");
      }
    }
  }
}
