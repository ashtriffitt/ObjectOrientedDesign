import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import model.Image;
import model.ImageModel;
import model.PixelImpl;
import model.Store;
import model.StoreImage;

import static org.junit.Assert.assertEquals;

/**
 * Represents the test class for image storage.
 */
public class StoreTest {
  Image mockImage;
  PixelImpl[][] pixels;

  Store imageStore;

  @Before
  public void init() {
    pixels = new PixelImpl[2][2];
    pixels[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    pixels[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    pixels[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    pixels[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    mockImage = new ImageModel(2,2,255, pixels);

    imageStore = new StoreImage();
  }

  @Test
  public void putContainTest() {
    imageStore.put("mock", mockImage);
    assertEquals(mockImage, imageStore.contain("mock"));
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidPutTest() {
    imageStore.put("invalid", null);
  }
}
