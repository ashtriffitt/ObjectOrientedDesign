import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.KernelImpl;
import model.Pixel;
import model.PixelImpl;

import static org.junit.Assert.assertEquals;

/**
 * Represents the test class for an individual pixel.
 */
public class PixelTest {
  Pixel p;

  @Before
  public void init() {
    p = new PixelImpl(Arrays.asList(2, 3, 4));
  }


  @Test
  public void testGetColor() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(2, 3, 4));
    assertEquals(p.getColor(), rgb);
  }

  @Test
  public void visRedTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(2, 2, 2));
    assertEquals(p.visualizeColor(0), rgb);
  }

  @Test
  public void visGreenTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(3, 3, 3));
    assertEquals(p.visualizeColor(1), rgb);
  }

  @Test
  public void visBlueTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(4, 4, 4));
    assertEquals(p.visualizeColor(2), rgb);
  }

  @Test
  public void visValueTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(4, 4, 4));
    assertEquals(p.visValue(), rgb);
  }

  @Test
  public void visIntensityTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(3, 3, 3));
    assertEquals(p.visIntensity(), rgb);
  }

  @Test
  public void visLumaTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(3, 3, 3));
    assertEquals(p.visLuma(), rgb);
  }

  @Test
  public void brightenTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(3, 4, 5));
    assertEquals(p.brighten(1), rgb);
  }

  @Test
  public void darkenTest() {
    List<Integer> rgb = new ArrayList<>(Arrays.asList(1, 2, 3));
    assertEquals(p.darken(1), rgb);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidInit() {
    List<Integer> invalid = null;
    Pixel pixel = new PixelImpl(invalid);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidVisColor() {
    p.visualizeColor(-1);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidBrighten() {
    p.visualizeColor(-1);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidDarken() {
    p.visualizeColor(-1);
  }
}
