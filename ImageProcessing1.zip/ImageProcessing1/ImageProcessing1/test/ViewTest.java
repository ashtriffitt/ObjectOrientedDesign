import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import model.Image;
import model.ImageModel;
import model.PixelImpl;
import model.Store;
import model.StoreImage;
import view.ImageView;
import view.View;

import static org.junit.Assert.assertEquals;

/**
 * Represents the test class for the view class.
 */
public class ViewTest {

  @Test
  public void testToString() {
    PixelImpl[][] pixels = new PixelImpl[2][2];
    pixels[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    pixels[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    pixels[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    pixels[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    Image mockImage = new ImageModel(2,2,255, pixels);

    Store imageStore = new StoreImage();
    imageStore.put("mock", mockImage);
    View view = new ImageView(imageStore);

    assertEquals(view.toString("mock"), "Height of Image: 2\n"
            + "Width of Image: 2\n"
            + "Maximum value of a color in this file (usually 255): 255\n"
            + " (1, 1, 3)(3, 1, 1) (1, 3, 1)(1, 1, 1)");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testInvalidInit() {
    Store invalidStore = null;
    View invalidView = new ImageView(invalidStore);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testInvalidInit2() {
    Store invalidStore = null;
    Appendable invalidApp = null;
    View invalidView = new ImageView(invalidStore, invalidApp);
  }
}
