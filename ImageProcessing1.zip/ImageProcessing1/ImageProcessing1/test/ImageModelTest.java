import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import model.Image;
import model.ImageModel;
import model.PixelImpl;

import static org.junit.Assert.assertEquals;

/**
 * Represents the test class for modifying a whole image.
 */
public class ImageModelTest {
  Image mockImage;
  Image mockImage2;
  PixelImpl[][] pixels;
  PixelImpl[][] pixels2;

  @Before
  public void init() {
    pixels = new PixelImpl[2][2];
    pixels[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    pixels[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    pixels[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    pixels[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    mockImage = new ImageModel(2,2,255, pixels);

    pixels2 = new PixelImpl[2][2];
    pixels2[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 4, 8)));
    pixels2[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 2, 1)));
    pixels2[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(5, 2, 1)));
    pixels2[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 6, 1)));
    mockImage2 = new ImageModel(2,2,255, pixels2);
  }

  @Test
  public void brightenTest() {
    mockImage.brighten(2);
    PixelImpl[][] brightenImage = new PixelImpl[2][2];
    brightenImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 5)));
    brightenImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(5, 3, 3)));
    brightenImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 5, 3)));
    brightenImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    String brightenPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        brightenPixels += brightenImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(brightenPixels, imageString);
  }

  @Test
  public void darkenTest() {
    mockImage.darken(2);
    PixelImpl[][] darkenImage = new PixelImpl[2][2];
    darkenImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(-1, -1, 1)));
    darkenImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, -1, -1)));
    darkenImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(-1, 1, -1)));
    darkenImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(-1, -1, -1)));
    String darkenPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        darkenPixels += darkenImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(darkenPixels, imageString);
  }

  @Test
  public void horizontalTest() {
    mockImage.flipHorizontal();
    PixelImpl[][] horizontalImage = new PixelImpl[2][2];
    horizontalImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    horizontalImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    horizontalImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    horizontalImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    String horizontalPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        horizontalPixels += horizontalImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(horizontalPixels, imageString);
  }

  @Test
  public void verticalTest() {
    mockImage.flipVertical();
    PixelImpl[][] verticalImage = new PixelImpl[2][2];
    verticalImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    verticalImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    verticalImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    verticalImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    String verticalPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        verticalPixels += verticalImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(verticalPixels, imageString);
  }

  @Test
  public void redVisTest() {
    mockImage.visualizeColor(0);
    PixelImpl[][] redVisImage = new PixelImpl[2][2];
    redVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    redVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    redVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    redVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    String redVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        redVisPixels += redVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(redVisPixels, imageString);
  }

  @Test
  public void greenVisTest() {
    mockImage.visualizeColor(1);
    PixelImpl[][] greenVisImage = new PixelImpl[2][2];
    greenVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    greenVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    greenVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    greenVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    String greenVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        greenVisPixels += greenVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(greenVisPixels, imageString);
  }

  @Test
  public void blueVisTest() {
    mockImage.visualizeColor(2);
    PixelImpl[][] blueVisImage = new PixelImpl[2][2];
    blueVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    blueVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    blueVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    blueVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    String blueVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        blueVisPixels += blueVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(blueVisPixels, imageString);
  }

  @Test
  public void intensityVisTest() {
    mockImage2.visIntensity();
    PixelImpl[][] intensityVisImage = new PixelImpl[2][2];
    intensityVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(4, 4, 4)));
    intensityVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 2, 2)));
    intensityVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 2, 2)));
    intensityVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 2, 2)));
    String intensityVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        intensityVisPixels += intensityVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(intensityVisPixels, imageString);
  }

  @Test
  public void lumaVisTest() {
    mockImage2.visLuma();
    PixelImpl[][] lumaVisImage = new PixelImpl[2][2];
    lumaVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(4, 4, 4)));
    lumaVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 2, 2)));
    lumaVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    lumaVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(5, 5, 5)));
    String lumaVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        lumaVisPixels += lumaVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(lumaVisPixels, imageString);
  }

  @Test
  public void valueVisTest() {
    mockImage2.visValue();
    PixelImpl[][] valueVisImage = new PixelImpl[2][2];
    valueVisImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(8, 8, 8)));
    valueVisImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 3)));
    valueVisImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(5, 5, 5)));
    valueVisImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(6, 6, 6)));
    String valueVisPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        valueVisPixels += valueVisImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(valueVisPixels, imageString);
  }

  @Test
  public void testBlur() {
    mockImage2.blur();
    PixelImpl[][] blurImage = new PixelImpl[2][2];
    blurImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(0, 1, 2)));
    blurImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(0, 0, 0)));
    blurImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 0, 0)));
    blurImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(0, 1, 0)));
    String blurPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        blurPixels += blurImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(blurPixels, imageString);
  }

  @Test
  public void testSepia() {
    mockImage2.sepia();
    PixelImpl[][] sepiaImage = new PixelImpl[2][2];
    sepiaImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(4, 4, 3)));
    sepiaImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 2, 2)));
    sepiaImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 3, 2)));
    sepiaImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(5, 4, 3)));
    String sepiaPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        sepiaPixels += sepiaImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(sepiaPixels, imageString);
  }

  @Test
  public void testSharpen() {
    mockImage2.sharpen();
    PixelImpl[][] sharpImage = new PixelImpl[2][2];
    sharpImage[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(2, 5, 8)));
    sharpImage[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(4, 4, 3)));
    sharpImage[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(6, 5, 3)));
    sharpImage[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 9, 3)));
    String sharpPixels = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        sharpPixels += sharpImage[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage2.getPixels()[i][j].getColor();
      }
    }
    assertEquals(sharpPixels, imageString);
  }

  @Test
  public void getWidthTest() {
    assertEquals(mockImage.getWidth(), 2);
  }

  @Test
  public void getHeightTest() {
    assertEquals(mockImage.getHeight(), 2);
  }

  @Test
  public void getMaxValTest() {
    assertEquals(mockImage.getMaxVal(), 255);
  }

  @Test
  public void getPixelsTest() {
    PixelImpl[][] pixelCopy = new PixelImpl[2][2];
    pixelCopy[0][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 3)));
    pixelCopy[0][1] = new PixelImpl(new ArrayList<>(Arrays.asList(3, 1, 1)));
    pixelCopy[1][0] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 3, 1)));
    pixelCopy[1][1] = new PixelImpl(new ArrayList<>(Arrays.asList(1, 1, 1)));
    String copy = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        copy += pixelCopy[i][j].getColor();
      }
    }
    String imageString = "";
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        imageString += mockImage.getPixels()[i][j].getColor();
      }
    }
    assertEquals(copy, imageString);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidInit() {
    Image invalidWidth = new ImageModel(0, 2, 255, pixels);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidInit2() {
    Image invalidHeight = new ImageModel(2, 0, 255, pixels);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidInit3() {
    Image invalidMaxVal = new ImageModel(2, 2, 0, pixels);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidInit4() {
    PixelImpl[][] invalidPixels = null;
    Image invalidPixelVal = new ImageModel(2, 2, 255, invalidPixels);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidVis() {
    mockImage.visualizeColor(-2);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidBrighten() {
    mockImage.brighten(-2);
  }

  @Test (expected = IllegalArgumentException.class)
  public void invalidDarken() {
    mockImage.darken(-2);
  }
}
